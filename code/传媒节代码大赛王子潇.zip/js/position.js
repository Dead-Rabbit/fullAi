function position(x,y,z){
	this.x = x;
	this.y = y;
	this.z = z;
};
position.prototype.setPosition = function(x,y,z) {
	this.x = x;
	this.y = y;
	this.z = z;
};